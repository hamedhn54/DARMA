export interface AIMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface AIProvider {
  name: string;
  generateResponse(messages: AIMessage[]): Promise<string>;
}
