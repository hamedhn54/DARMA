import { useCallback, useEffect, useMemo, useState } from "react";
import { ArrowDownLeft, ArrowLeftRight, ArrowUpRight, RefreshCw, Search, CalendarDays, ChevronLeft, ChevronRight, Pencil, Ban, Trash2, FileText, X } from "lucide-react";
import { addMonths, eachDayOfInterval, endOfMonth, format, getDay, startOfMonth, subMonths } from "date-fns-jalali";
import { definitionsDb, type DefinitionRecord, type JournalEntry } from "../database/definitionsDb";
import { deleteTestFinancialTransaction, getFinancialTransactions, postFinancialTransaction, updateFinancialTransaction, voidFinancialTransaction, type FinancialTransactionType } from "../services/transactionService";
import "./TransactionsPage.css";

const labels: Record<FinancialTransactionType, string> = { income: "دریافت", expense: "پرداخت", transfer: "انتقال" };
const money = (value: number) => `${new Intl.NumberFormat("fa-IR").format(Math.abs(value))} ریال`;
const latinDigits = (value: string) => value.replace(/[۰-۹]/g, d => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[٠-٩]/g, d => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
const jalali = (d: Date) => format(d, "yyyy/MM/dd");
const weekdays = ["ش", "ی", "د", "س", "چ", "پ", "ج"];
function JalaliDateField({ value, onChange }: { value: Date; onChange: (date: Date) => void }) {
 const [open,setOpen]=useState(false);const [month,setMonth]=useState(startOfMonth(value));
 const days=eachDayOfInterval({start:startOfMonth(month),end:endOfMonth(month)});const offset=(getDay(startOfMonth(month))+1)%7;
 return <label>تاریخ شمسی<div className="tx-date-wrap"><input readOnly value={jalali(value)} onClick={()=>{setMonth(startOfMonth(value));setOpen(v=>!v)}}/><button type="button" onClick={()=>{setMonth(startOfMonth(value));setOpen(v=>!v)}}><CalendarDays size={16}/></button>{open&&<div className="tx-calendar"><div className="tx-calendar-head"><button type="button" onClick={()=>setMonth(m=>addMonths(m,1))}><ChevronRight size={16}/></button><b>{format(month,"MMMM yyyy")}</b><button type="button" onClick={()=>setMonth(m=>subMonths(m,1))}><ChevronLeft size={16}/></button></div><div className="tx-calendar-grid">{weekdays.map(d=><span key={d}>{d}</span>)}{Array.from({length:offset},(_,i)=><i key={`b${i}`}/>)}{days.map(d=><button type="button" key={d.toISOString()} className={jalali(d)===jalali(value)?"selected":""} onClick={()=>{onChange(d);setOpen(false)}}>{format(d,"d")}</button>)}</div><div className="tx-calendar-foot"><button type="button" onClick={()=>{onChange(new Date());setOpen(false)}}>امروز</button><button type="button" onClick={()=>setOpen(false)}>بستن</button></div></div>}</div></label>;
}

export default function TransactionsPage() {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [accounts, setAccounts] = useState<DefinitionRecord[]>([]);
  const [categories, setCategories] = useState<DefinitionRecord[]>([]);
  const [type, setType] = useState<FinancialTransactionType>("expense");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(new Date());
  const [description, setDescription] = useState("");
  const [accountId, setAccountId] = useState("");
  const [fromAccountId, setFromAccountId] = useState("");
  const [toAccountId, setToAccountId] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [isTest, setIsTest] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [detailEntry, setDetailEntry] = useState<JournalEntry | null>(null);
  const [detailLines, setDetailLines] = useState<import("../database/definitionsDb").JournalLine[]>([]);
  const [query, setQuery] = useState("");
  const [filterType, setFilterType] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const refresh = useCallback(async () => {
    const [a, e] = await Promise.all([definitionsDb.definitions.toArray(), getFinancialTransactions()]);
    const cash = a.filter(x => ["bank", "cash", "wallet"].includes(x.kind));
    setAccounts(cash); setCategories(a.filter(x => x.kind !== "person" && x.parentId !== null && (x.root === "income" || x.root === "expenses"))); setEntries(e);
    setAccountId(v => v || cash[0]?.id || ""); setFromAccountId(v => v || cash[0]?.id || ""); setToAccountId(v => v || cash[1]?.id || "");
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);
  const visible = useMemo(() => entries.filter(e => e.status !== "void" && (!filterType || e.type === filterType) && (!query || `${e.description} ${e.docNo}`.toLowerCase().includes(query.toLowerCase()))), [entries, filterType, query]);
  const startEdit = (entry: JournalEntry) => {
    if (entry.type !== "income" && entry.type !== "expense" && entry.type !== "transfer") return;
    setEditingId(entry.id); setType(entry.type); setAmount(new Intl.NumberFormat("fa-IR").format(entry.amount));
    setDate(new Date(entry.date)); setDescription(entry.description); setAccountId(entry.cashAccountId || "");
    setFromAccountId(entry.fromAccountId || ""); setToAccountId(entry.toAccountId || ""); setCategoryId(entry.categoryId || ""); setIsTest(!!entry.isTest);
    window.scrollTo({top:0,behavior:"smooth"});
  };
  const cancelEdit = () => { setEditingId(null); setAmount(""); setDescription(""); setCategoryId(""); setIsTest(false); };
  const openDetails = async (entry: JournalEntry) => { setDetailEntry(entry); setDetailLines(await definitionsDb.journalLines.where("entryId").equals(entry.id).toArray()); };
  const lineName = (line: import("../database/definitionsDb").JournalLine) => {
    if (line.cashAccountId) return accounts.find(a=>a.id===line.cashAccountId)?.name || "حساب حذف‌شده";
    const id=line.accountCode.split(":").slice(1).join(":");
    return categories.find(c=>c.id===id)?.name || (line.accountCode.startsWith("income:")?"درآمد بدون دسته‌بندی":"هزینه بدون دسته‌بندی");
  };
  const voidEntry = async (entry: JournalEntry) => { const reason=window.prompt("علت ابطال سند:","ثبت اشتباه"); if(reason===null)return; if(!window.confirm(`سند شماره ${entry.docNo||"—"} باطل شود؟`))return; await voidFinancialTransaction(entry.id,reason); await refresh(); };
  const deleteTest = async (entry: JournalEntry) => { if(!window.confirm(`سند آزمایشی شماره ${entry.docNo||"—"} برای همیشه حذف شود؟`))return; await deleteTestFinancialTransaction(entry.id); await refresh(); };
  const save = async () => {
    setError(""); setBusy(true);
    try {
      const numeric = Number(latinDigits(amount).replace(/[^0-9]/g, ""));
      const input = { type, amount: numeric, date: date.toISOString(), description, accountId, fromAccountId, toAccountId, categoryId: categoryId || undefined, isTest };
      if (editingId) await updateFinancialTransaction(editingId, input); else await postFinancialTransaction(input);
      setEditingId(null); setAmount(""); setDescription(""); setCategoryId(""); setIsTest(false); await refresh();
    } catch (e) { setError(e instanceof Error ? e.message : "ثبت تراکنش انجام نشد."); }
    finally { setBusy(false); }
  };
  return <main className="tx-page" dir="rtl">
    <header className="tx-heading"><div><span>دفترکل مشترک دارما</span><h1>تراکنش‌ها</h1><p>دریافت، پرداخت و انتقال؛ هر عملیات با سند دوطرفه در دفترکل ثبت می‌شود.</p></div><button onClick={() => void refresh()}><RefreshCw size={16}/> به‌روزرسانی</button></header>
    <section className="tx-layout">
      <article className="tx-panel tx-form-panel"><div className="tx-title"><h2>{editingId?"ویرایش تراکنش":"ثبت تراکنش جدید"}</h2><span>سند حسابداری خودکار</span></div>
        <div className="tx-type-tabs">{(["income","expense","transfer"] as FinancialTransactionType[]).map(t => <button key={t} className={type===t?"active":""} onClick={()=>setType(t)}>{t==="income"?<ArrowDownLeft size={17}/>:t==="expense"?<ArrowUpRight size={17}/>:<ArrowLeftRight size={17}/>} {labels[t]}</button>)}</div>
        <div className="tx-fields"><label>مبلغ (ریال)<input inputMode="numeric" value={amount} onChange={e=>{const raw=latinDigits(e.target.value).replace(/[^0-9]/g,"");setAmount(raw?new Intl.NumberFormat("fa-IR").format(Number(raw)):"")}} placeholder="مثلاً ۱۲٬۵۰۰٬۰۰۰"/></label>
          <JalaliDateField value={date} onChange={setDate}/>
          {type !== "transfer" && <label>حساب {type === "income" ? "واریز به" : "پرداخت از"}<select value={accountId} onChange={e=>setAccountId(e.target.value)}><option value="">انتخاب حساب</option>{accounts.map(a=><option key={a.id} value={a.id}>{a.name}</option>)}</select></label>}
          {type === "transfer" && <><label>حساب مبدأ<select value={fromAccountId} onChange={e=>setFromAccountId(e.target.value)}><option value="">انتخاب مبدأ</option>{accounts.map(a=><option key={a.id} value={a.id}>{a.name}</option>)}</select></label><label>حساب مقصد<select value={toAccountId} onChange={e=>setToAccountId(e.target.value)}><option value="">انتخاب مقصد</option>{accounts.map(a=><option key={a.id} value={a.id}>{a.name}</option>)}</select></label></>}
          {type !== "transfer" && <label>دسته‌بندی<select value={categoryId} onChange={e=>setCategoryId(e.target.value)}><option value="">بدون دسته‌بندی</option>{categories.filter(c=>c.root===(type==="income"?"income":"expenses")).map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>}
          <label className="tx-wide">شرح تراکنش<input value={description} onChange={e=>setDescription(e.target.value)} placeholder="شرح مختصر و قابل پیگیری"/></label>
        </div>
        <label className="tx-test"><input type="checkbox" checked={isTest} onChange={e=>setIsTest(e.target.checked)}/> ثبت به‌عنوان سند آزمایشی</label>
        {error && <p className="tx-error">{error}</p>}
        <button className="tx-submit" disabled={busy || accounts.length===0} onClick={()=>void save()}>{busy?"در حال ذخیره...":editingId?"ذخیره ویرایش":"ثبت تراکنش"}</button>{editingId&&<button className="tx-cancel" onClick={cancelEdit}>انصراف از ویرایش</button>}
        {accounts.length===0 && <p className="tx-warning">برای ثبت تراکنش، ابتدا در تعاریف یک حساب بانکی، صندوق یا کیف پول ایجاد کن.</p>}
      </article>
      <article className="tx-panel tx-list-panel"><div className="tx-title"><div><h2>دفتر تراکنش‌ها</h2><small>{visible.length.toLocaleString("fa-IR")} سند</small></div><div className="tx-filter"><Search size={15}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="جست‌وجوی شرح یا شماره"/><select value={filterType} onChange={e=>setFilterType(e.target.value)}><option value="">همه انواع</option><option value="income">دریافت</option><option value="expense">پرداخت</option><option value="transfer">انتقال</option></select></div></div>
        {visible.length ? visible.map(e=><div className="tx-row" key={e.id}><span className={`tx-icon ${e.type}`}>{e.type==="income"?<ArrowDownLeft size={17}/>:e.type==="expense"?<ArrowUpRight size={17}/>:<ArrowLeftRight size={17}/>}</span><span className="tx-row-info"><b>سند {e.docNo?.toLocaleString("fa-IR")} · {labels[e.type as FinancialTransactionType]}</b><small>{e.description} · {new Intl.DateTimeFormat("fa-IR").format(new Date(e.date))}{e.isTest?" · آزمایشی":""}</small></span><strong>{money(e.amount)}</strong><div className="tx-row-actions"><button title="جزئیات سند" onClick={()=>void openDetails(e)}><FileText size={14}/></button><button title="ویرایش سند" onClick={()=>startEdit(e)}><Pencil size={14}/></button><button title="ابطال سند" onClick={()=>void voidEntry(e)}><Ban size={14}/></button>{e.isTest&&<button title="حذف سند آزمایشی" onClick={()=>void deleteTest(e)}><Trash2 size={14}/></button>}</div></div>):<div className="tx-empty">هنوز تراکنش عمومی ثبت نشده است.</div>}
      </article>
    </section>
    {detailEntry&&<div className="tx-modal-backdrop" onClick={()=>setDetailEntry(null)}><section className="tx-modal" onClick={e=>e.stopPropagation()}><header><div><h2>جزئیات سند حسابداری</h2><small>شماره {detailEntry.docNo?.toLocaleString("fa-IR")||"—"}</small></div><button onClick={()=>setDetailEntry(null)}><X size={17}/></button></header><div className="tx-modal-meta"><span>نوع: {labels[detailEntry.type as FinancialTransactionType]}</span><span>تاریخ: {new Intl.DateTimeFormat("fa-IR").format(new Date(detailEntry.date))}</span><span>شرح: {detailEntry.description}</span><span>مبلغ: {money(detailEntry.amount)}</span></div><table><thead><tr><th>حساب</th><th>بدهکار</th><th>بستانکار</th></tr></thead><tbody>{detailLines.map(line=><tr key={line.id}><td>{lineName(line)}</td><td>{line.debit?money(line.debit):"—"}</td><td>{line.credit?money(line.credit):"—"}</td></tr>)}</tbody><tfoot><tr><th>جمع</th><th>{money(detailLines.reduce((s,l)=>s+l.debit,0))}</th><th>{money(detailLines.reduce((s,l)=>s+l.credit,0))}</th></tr></tfoot></table></section></div>}
  </main>;
}
